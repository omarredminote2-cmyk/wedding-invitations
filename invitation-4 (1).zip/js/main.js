(() => {
  const C = INVITATION, $ = (i) => document.getElementById(i);
  const U = (p) => (window.PREVIEW && PREVIEW[p]) || p;
  const tp = $("tpl"); if (tp) document.body.prepend(tp.content.cloneNode(true));
  const stage = $("stage"), intro = $("intro"), iv = $("introVideo"), bg = $("bg"), cal = $("cal"),
        mapBtn = $("mapBtn"), gal = $("gallery"), promo = $("promo");
  bg.src = U(bg.dataset.src); iv.src = U(iv.dataset.src); iv.poster = U(iv.dataset.poster);

  const AD = "٠١٢٣٤٥٦٧٨٩";
  const MO = "يناير فبراير مارس أبريل مايو يونيو يوليو أغسطس سبتمبر أكتوبر نوفمبر ديسمبر".split(" ");
  const DN = "الأحد الاثنين الثلاثاء الأربعاء الخميس الجمعة السبت".split(" ");
  const DI = "ح ن ث ر خ ج س".split(" ");
  const dg = (s) => C.event.digits === "en" ? String(s) : String(s).replace(/\d/g, (d) => AD[d]);
  const get = (o, p) => p.split(".").reduce((a, k) => (a == null ? a : a[k]), o);

  function derive() {
    const e = C.event, d = e.date, y = +d.year, m = +d.month - 1;
    const n = new Date(y, m + 1, 0).getDate(), day = Math.min(Math.max(+d.day || 1, 1), n);
    const wd = new Date(y, m, day).getDay();
    const [h, mi] = String(e.time || "").split(":").map(Number), ok = e.time && !isNaN(h);
    return { y, m, n, day, x: {
      weekday: (e.weekday || DN[wd]) + " الموافق",
      date: dg(day) + " " + MO[m] + " " + dg(y),
      time: ok ? "الساعة " + dg((h % 12 || 12) + ":" + String(mi || 0).padStart(2, "0")) + " " + (h < 12 ? "صباحًا" : "مساءً") : ""
    } };
  }

  // ---- الموسيقى ----
  const music = new Audio(); music.loop = true;
  const sync = () => {};
  const musicOn = () => C.music && C.music.enabled && C.music.file;
  function applyMusic() {
    if (!musicOn()) { music.pause(); return; }
    const s = U(C.music.file);
    if (music.dataset.s !== s) { const was = !music.paused; music.dataset.s = s; music.src = s; if (was) music.play().catch(() => {}); }
    music.volume = Math.min(Math.max(C.music.volume ?? 0.5, 0), 1);
    sync();
  }

  // ---- رسم الدعوة (تُستدعى عند أي تعديل) ----
  function render() {
    const D = derive(), S = Object.assign({}, C, { x: D.x });
    document.title = C.pageTitle;
    document.querySelectorAll("[data-f]").forEach((el) => {
      const v = get(S, el.dataset.f);
      if (v !== undefined) { el.textContent = v; el.hidden = v === ""; }
    });
    // الكاليندر: الشهر والصفوف والقلب على اليوم المختار
    cal.hidden = C.event.showCalendar === false;
    const fd = Number(C.event.firstDay) || 0, off = (new Date(D.y, D.m, 1).getDay() - fd + 7) % 7;
    let h = `<h3>${MO[D.m]} ${dg(D.y)}</h3><div class="g">`;
    for (let i = 0; i < 7; i++) h += `<b>${DI[(fd + i) % 7]}</b>`;
    for (let i = 0; i < off; i++) h += "<span></span>";
    for (let d = 1; d <= D.n; d++) h += `<span data-d="${d}"${d === D.day ? ' class="on"' : ""}>${dg(d)}</span>`;
    cal.innerHTML = h + "</div>";
    // الخريطة
    const u = C.venue.mapUrl || "";
    mapBtn.href = /^https?:\/\//i.test(u) ? u : "#";
    mapBtn.hidden = mapBtn.hidden || C.venue.showMap === false || !/^https?:\/\//i.test(u);
    // زر واتساب في آخر الدعوة
    const pr = C.promo || {}, ph = String(pr.whatsapp || "").replace(/\D/g, "");
    promo.hidden = !pr.text || !ph; promo.href = ph ? "https://wa.me/" + ph : "#";
    // الصور
    const sig = C.photos.map((p) => U(p.src)).join("|");
    if (gal.dataset.s !== sig) {
      gal.dataset.s = sig; gal.textContent = "";
      C.photos.forEach((p) => {
        const f = document.createElement("div"), i = new Image();
        f.className = "frame"; i.src = U(p.src); i.alt = p.alt || ""; f.append(i); gal.append(f);
      });
    }
    applyMusic();
  }

  // ---- الافتتاح ----
  let started = false, opened = false;
  function start() {
    if (started) return;
    started = true; iv.muted = true; iv.volume = 0;
    if (musicOn()) music.play().catch(() => {});
    iv.play().catch(openInvitation);
  }
  function openInvitation() {
    if (opened) return;
    opened = true; bg.muted = true; bg.currentTime = 0; bg.play().catch(() => {});
    stage.removeAttribute("inert"); intro.classList.add("done");
    setTimeout(() => { intro.hidden = true; }, 1000);
    if (musicOn()) music.play().catch(sync);
  }
  intro.addEventListener("click", start);
  intro.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); start(); } });
  iv.addEventListener("ended", openInvitation);
  iv.addEventListener("error", openInvitation);

  window.INV = { render, open: openInvitation };
  render();
})();
