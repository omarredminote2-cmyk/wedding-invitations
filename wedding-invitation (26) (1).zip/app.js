(function () {
'use strict';
const CFG = window.CONFIG || {};
const AR = '٠١٢٣٤٥٦٧٨٩';
const ar = s => CFG.digits === 'en' ? String(s) : String(s).replace(/\d/g, d => AR[d]);
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const br = s => esc(s).replace(/\n/g, '<br>');
const t = (cls, s) => s ? `<p class="${cls}">${br(s)}</p>` : '';
const MONTHS = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
const DAYS = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
const LET = ['ح','ن','ث','ر','خ','ج','س'];
const WS = { sun: 0, mon: 1, sat: 6 };

/* ===== التاريخ والوقت ===== */
function date() {
  const d = CFG.date || {};
  const year = +d.year || 2027, month = Math.min(12, Math.max(1, +d.month || 1));
  const len = new Date(year, month, 0).getDate();
  return { year, month, day: Math.min(len, Math.max(1, +d.day || 1)), len };
}
const dayName = () => { const x = date(); return DAYS[new Date(x.year, x.month - 1, x.day).getDay()]; };
const dateLine = () => { const x = date(); return `${dayName()} ${ar(x.day)} ${MONTHS[x.month - 1]}`; };
function fmtTime(s, short) {
  const m = /^(\d{1,2}):(\d{2})/.exec(s || '');
  if (!m) return s || '';
  const h = +m[1], pm = h >= 12;
  return ar((h % 12 || 12) + ':' + m[2]) + (short ? (pm ? ' م' : ' ص') : (pm ? ' مساءً' : ' صباحاً'));
}
function calendar() {
  const x = date(), ws = WS[CFG.weekStart] ?? 6;
  const off = (new Date(x.year, x.month - 1, 1).getDay() - ws + 7) % 7;
  let c = ''; for (let i = 0; i < off; i++) c += '<span></span>';
  for (let i = 1; i <= x.len; i++) c += `<span${i === x.day ? ' class="me"' : ''}>${ar(i)}</span>`;
  return `<div class="cal">${[0,1,2,3,4,5,6].map(i => `<b>${LET[(ws + i) % 7]}</b>`).join('')}${c}</div>`;
}

/* ===== الصفحات ===== */
const mapQ = () => CFG.mapQuery || [CFG.venue, CFG.address, CFG.city].filter(Boolean).join(' ');
const mapLink = () => /^https?:\/\//.test(CFG.mapLink || '') ? CFG.mapLink : 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(mapQ());
const mapSvg = '<svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><path d="M0 62L100 38M30 0L55 100M0 20L100 85M78 0L66 100" stroke="#f4efe3" stroke-width="6" fill="none"/><path d="M0 62L100 38M30 0L55 100M0 20L100 85M78 0L66 100" stroke="#b9b09c" stroke-width=".6" fill="none"/><path d="M50 28c-8 0-14 6-14 14 0 11 14 26 14 26s14-15 14-26c0-8-6-14-14-14z" fill="#7a2230"/><circle cx="50" cy="42" r="5" fill="#f4efe3"/></svg>';

const page1 = () => t('sm', CFG.bismillah) + t('sm', CFG.verse)
  + (CFG.bismillah || CFG.verse ? '<div class="rule"></div>' : '')
  + t('', CFG.invitation)
  + (CFG.groom || CFG.bride ? `<h1 class="names"><span>${esc(CFG.groom)}</span>${CFG.groom && CFG.bride ? '<i>و</i>' : ''}<span>${esc(CFG.bride)}</span></h1>` : '')
  + t('sm', CFG.dua)
  + (CFG.closing ? '<div class="rule"></div>' : '') + t('sm', CFG.closing);

const page2 = () => `<h2 class="h">موعد الفرح</h2><p class="big">${MONTHS[date().month - 1]} ${ar(date().year)}</p>${calendar()}<p class="big">${dateLine()}</p>${CFG.time ? `<p>الساعة ${fmtTime(CFG.time)}</p>` : ''}`;

const page3 = () => {
  const sub = [CFG.address, CFG.city].filter(Boolean).join('، ');
  return '<h2 class="h">مكان الفرح</h2>'
    + (mapQ() ? `<div class="map">${mapSvg}<iframe title="خريطة مكان الفرح" loading="lazy" referrerpolicy="no-referrer-when-downgrade" src="https://www.google.com/maps?q=${encodeURIComponent(mapQ())}&output=embed"></iframe></div>` : '')
    + (CFG.venue || sub ? `<p class="big">${esc(CFG.venue)}${sub ? `<br><span class="sm" style="font-weight:400">${esc(sub)}</span>` : ''}</p>` : '')
    + (mapQ() ? `<a class="btn" target="_blank" rel="noopener" href="${esc(mapLink())}">افتح في خرائط جوجل</a>` : '');
};

const page4 = () => `<h2 class="h">برنامج الحفل</h2><ol class="prog">${CFG.program.map(r => `<li><time>${fmtTime(r[0], true)}</time><span>${esc(r[1])}</span></li>`).join('')}</ol><p class="sm">${dateLine()}</p>`;

const page5 = () => `<h2 class="h">تأكيد الحضور</h2><div class="rule"></div><p>يسعدنا تأكيدكم الحضور<br>وعدد المرافقين</p><a class="btn" target="_blank" rel="noopener" href="https://wa.me/${esc(String(CFG.rsvpPhone).replace(/\D/g, ''))}?text=${encodeURIComponent('أؤكد حضوري حفل زفاف ' + (CFG.groom || '') + ' و' + (CFG.bride || ''))}">أكّد عبر واتساب</a>`;

const P = () => [
  { k: 'الدعوة', html: page1 },
  CFG.showCalendar !== false && { k: 'الموعد', html: page2 },
  CFG.showMap !== false && { k: 'المكان', html: page3 },
  Array.isArray(CFG.program) && CFG.program.length && { k: 'البرنامج', html: page4 },
  CFG.rsvpPhone && { k: 'تأكيد الحضور', html: page5 }
].filter(Boolean);

/* ===== القرص ===== */
const POS = [[82,32.9],[69.4,19.2],[51.7,13.3],[33.5,16.5],[19,28.1],[11.8,45.3],[13.3,63.6],[22.3,76.8],[35.5,84.7],[51.6,87.5]];
const STOP = 58.7;
const ROT = POS.map(([x, y]) => (STOP - Math.atan2(y - 50, x - 50) * 180 / Math.PI + 360) % 360);
const plate = document.getElementById('plate'), dial = document.getElementById('dial');
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
let cur = 0, busy = false;

const keys = POS.map(([x, y], i) => {
  const b = document.createElement('button'); b.className = 'key';
  b.style.left = x + '%'; b.style.top = y + '%';
  b.onclick = () => go(i < P().length ? i : (cur + 1) % P().length, ROT[i]);
  dial.appendChild(b); return b;
});
const press = document.createElement('button'); press.className = 'key press'; press.setAttribute('aria-label', 'التالي');
dial.appendChild(press);
dial.onclick = e => { if (!e.target.closest('.key:not(.press)')) go((cur + 1) % P().length, 200); };

function mark() {
  const pages = P();
  keys.forEach((k, i) => {
    const on = i < pages.length;
    k.classList.toggle('cur', i === cur); k.classList.toggle('on', on); k.classList.toggle('off', !on);
    k.tabIndex = on ? 0 : -1;
    k.setAttribute('aria-label', 'الرقم ' + ar((i + 1) % 10) + (on ? ': ' + pages[i].k : ''));
  });
}
function fit(pg) {
  const f = pg && pg.firstElementChild; if (!f) return;
  f.style.transform = '';
  const s = Math.min(1, plate.clientHeight * .97 / f.offsetHeight, plate.clientWidth * 1.02 / f.scrollWidth);
  if (s < 1) f.style.transform = `scale(${s})`;
}
function render(i, instant) {
  cur = i; const pg = document.createElement('div'); pg.className = instant ? 'pg' : 'pg out';
  const p = P()[i]; pg.innerHTML = '<div class="fit">' + (p ? p.html() : '') + '</div>';
  plate.replaceChildren(pg); fit(pg);
  if (!instant) requestAnimationFrame(() => requestAnimationFrame(() => pg.classList.remove('out')));
  mark();
}
function spin(tf, ms, ease) { dial.style.transition = `transform ${ms}ms ${ease}`; dial.style.transform = tf; }
function go(n, ang) {
  if (busy || !P().length) return;
  busy = true;
  const old = plate.firstElementChild; if (old) old.classList.add('out');
  if (reduce) { setTimeout(() => { render(n); busy = false; }, 400); return; }
  const a = ang ?? ROT[n], tm = 380 + a / 360 * 620;
  spin(`rotate(${a}deg)`, tm, 'cubic-bezier(.45,.05,.35,1)');
  setTimeout(() => { render(n); spin('rotate(0deg) scale(1)', 780, 'cubic-bezier(.25,1.45,.5,1)'); }, tm + 60);
  setTimeout(() => { busy = false; }, tm + 60 + 800);
}

/* ===== الموسيقى ===== */
let A = null, btn = null, userPaused = false;
const vol = () => Math.min(1, Math.max(0, (CFG.music || {}).volume ?? .5));
function sync() { if (btn && A) { btn.classList.toggle('off', A.paused); btn.textContent = '♪'; } }
function initMusic() {
  const m = CFG.music || {};
  if (A) { A.pause(); A = null; }
  if (btn) { btn.remove(); btn = null; }
  if (!m.enabled || !(window.__MSRC || m.file)) return;
  A = new Audio(window.__MSRC || m.file); A.loop = true; A.volume = vol();
  A.addEventListener('canplay', () => {
    if (btn) return;
    btn = document.createElement('button'); btn.className = 'mus'; btn.setAttribute('aria-label', 'تشغيل أو إيقاف الموسيقى');
    btn.onclick = e => { e.stopPropagation(); userPaused = !A.paused; A.paused ? A.play().catch(() => {}) : A.pause(); };
    document.body.appendChild(btn); sync();
  });
  A.addEventListener('play', sync); A.addEventListener('pause', sync);
}
document.addEventListener('pointerdown', () => { if (A && A.paused && !userPaused) A.play().catch(() => {}); }, { once: true });

/* ===== الفوتر ورسالة الواتس ===== */
const WA = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2c-1.5 0-2.9-.4-4.1-1.1l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2z"/><path d="M16.6 14.4c-.2-.1-1.4-.7-1.6-.8-.2-.1-.4-.1-.6.1l-.8 1c-.1.2-.3.2-.5.1-.7-.3-1.6-.8-2.5-1.8-.5-.6-1-1.3-1.1-1.5-.1-.2 0-.4.1-.5l.4-.5.2-.4c.1-.2 0-.3 0-.5l-.7-1.7c-.2-.4-.3-.4-.5-.4h-.5c-.2 0-.5.1-.7.3-.2.3-.9.9-.9 2.1 0 1.2.9 2.4 1 2.6.1.2 1.8 2.8 4.3 3.8 1.6.7 2.2.7 3 .6.5-.1 1.4-.6 1.6-1.2.2-.6.2-1.1.1-1.2l-.4-.2z"/></svg>';
const autoLabel = () => 'دعوة زفاف' + (CFG.groom || CFG.bride ? ' ' + [CFG.groom, CFG.bride].filter(Boolean).join(' و') : '');
const label = () => String(CFG.shareName || '').trim() || autoLabel();
let foot = null;
function footer() {
  const ph = String(CFG.contactPhone || '').replace(/\D/g, '');
  if (!CFG.contactText || !ph) { if (foot) { foot.remove(); foot = null; } return; }
  if (!foot) { foot = document.createElement('footer'); foot.className = 'credit'; document.body.appendChild(foot); }
  const text = 'السلام عليكم، شفت «' + label() + '» وعايز أعمل دعوة على ذوقي';
  foot.innerHTML = `<a href="https://wa.me/${ph}?text=${encodeURIComponent(text)}" target="_blank" rel="noopener" aria-label="تواصل معنا على واتساب"><span>${esc(CFG.contactText)}</span>${WA}</a>`;
}

/* ===== تشغيل ===== */
function refresh() {
  if (cur >= P().length) cur = 0;
  render(cur, true); footer();
  document.title = 'دعوة زفاف ' + [CFG.groom, CFG.bride].filter(Boolean).join(' و');
}
document.title = 'دعوة زفاف ' + [CFG.groom, CFG.bride].filter(Boolean).join(' و');
render(0); footer(); initMusic();
document.fonts && document.fonts.ready.then(() => fit(plate.firstElementChild));
window.WED = { cfg: CFG, refresh, initMusic, volume: () => { if (A) A.volume = vol(); }, dateLine, date, autoLabel };
})();
