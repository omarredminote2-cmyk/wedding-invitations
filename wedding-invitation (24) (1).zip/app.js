(function(){
const C=window.CONFIG,M=window.MEDIA||{},$=s=>document.querySelector(s),st=$('#st'),R=p=>M[p]||p;
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const br=s=>esc(s).replace(/\n/g,'<br>');
const MON=['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
const WD=['الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'],WL='حنثرخجس',NC='ادذرزوؤأإآءةى';
const WA='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>';
let v,a,w,started=false;

function blobUrl(d){const m=d.slice(5,d.indexOf(';')),s=atob(d.split(',')[1]),n=new Uint8Array(s.length);for(let i=0;i<s.length;i++)n[i]=s.charCodeAt(i);return URL.createObjectURL(new Blob([n],{type:m}))}
function setSrc(el,p){const d=R(p);el.dataset.p=p;el.addEventListener('error',()=>{if(d.slice(0,5)==='data:')try{el.src=blobUrl(d)}catch(e){}},{once:true});el.src=d}
function stretch(s,n){s=String(s).trim();n=+n;if(!n||s.includes('ـ'))return s;
  for(let i=s.length-2;i>=0;i--)if(/[\u0621-\u064A]/.test(s[i])&&!NC.includes(s[i]))return s.slice(0,i+1)+'ـ'.repeat(n)+s.slice(i+1);
  return s}
function t12(t){let [h,m]=String(t||'0:0').split(':').map(Number);const p=h>=12?'مساءً':'صباحاً';return (h%12||12)+':'+String(m||0).padStart(2,'0')+' '+p}
function cal(y,m,d,ws){ws=+ws||0;const off=(new Date(y,m-1,1).getDay()-ws+7)%7,n=new Date(y,m,0).getDate();
  let h='<b class="cm">'+MON[m-1]+' '+y+'</b><div class="cg">';
  for(let i=0;i<7;i++)h+='<i>'+WL[(ws+i)%7]+'</i>';
  for(let i=0;i<off;i++)h+='<u></u>';
  for(let i=1;i<=n;i++)h+='<span'+(i==d?' class="on"':'')+'>'+i+'</span>';
  return h+'</div>'}

function music(){const k=C.music;if(a.dataset.p!==k.file)setSrc(a,k.file);a.volume=Math.min(1,Math.max(0,+k.volume||0));
  if(started)k.enabled?a.play().catch(()=>{}):a.pause()}

function render(){
  const [y,m,d]=String(C.date).split('-').map(Number),T=C.text,k=C.contact,S=C.share;
  if(!(y&&m&&d))return;
  document.title=String(S.title).replace(/\{names\}/g,C.groom+' و'+C.bride);
  $('#hint').textContent=T.tap;
  $('#tx').innerHTML=
   '<p class="bless l" style="--i:1">'+br(T.blessing)+'</p><div class="rule l" style="--i:2"></div>'+
   '<p class="joy l" style="--i:3">'+br(T.joy)+'</p><p class="inv l" style="--i:4">'+br(T.invite)+'</p>'+
   '<div class="nm l" style="--i:5"><span>'+esc(stretch(C.groom,C.kashida))+'</span><i>&amp;</i><span>'+esc(stretch(C.bride,C.kashida))+'</span></div>'+
   '<p class="will l" style="--i:6">'+br(T.will)+'</p>'+
   '<div class="info l" style="--i:7"><div class="det"><span>'+WD[new Date(y,m-1,d).getDay()]+' '+d+'.'+m+'.'+y+'</span><span>'+t12(C.time)+'</span><span>'+esc(C.venue)+'</span></div><div class="cal">'+cal(y,m,d,C.weekStart)+'</div></div>'+
   '<p class="end l" style="--i:8">'+br(T.end)+'</p>';
  if(started)st.classList.add('done');
  const msg=String(k.message||'').replace('{names}',C.groom+' و'+C.bride);
  w.hidden=!k.enabled;
  w.innerHTML='<a href="https://wa.me/'+esc(String(k.phone).replace(/\D/g,''))+(msg?'?text='+encodeURIComponent(msg):'')+'" target="_blank" rel="noopener" aria-label="واتساب">'+WA+'<span>'+esc(k.text)+'</span></a>';
  music();
}
function start(){if(started)return;started=true;document.body.classList.add('open');music();const go=()=>st.classList.add('go');v.play().then(go,go)}
function fit(){st.style.setProperty('--w',st.clientWidth+'px')}

st.innerHTML='<video id="v" playsinline muted preload="auto" disablepictureinpicture></video><audio id="a" preload="auto" loop></audio><section id="tx"></section><div id="hint"></div>';
w=document.createElement('div');w.id='wa';document.body.append(w);w.addEventListener('click',e=>e.stopPropagation());
v=$('#v');a=$('#a');v.poster=R(C.poster);setSrc(v,C.video);
fit();new ResizeObserver(fit).observe(st);
render();
addEventListener('click',start);
addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&!/INPUT|TEXTAREA|SELECT/.test(e.target.tagName))start()});
document.addEventListener('visibilitychange',()=>{if(started&&C.music.enabled)document.hidden?a.pause():a.play().catch(()=>{})});
window.App={render,start};
})();
