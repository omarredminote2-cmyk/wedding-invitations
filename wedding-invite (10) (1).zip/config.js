/* ملف الإعدادات (اتعمل من محرر الدعوة، وتقدر تعدّله بإيدك برضو: غيّر القيم وسيب الباقي) */
const INVITE = {
  "groom": "عمر",
  "bride": "سلمى",
  "greeting": "إلى من هم أغلى من الروح سروري سيبقى مختلفاً بحضوركم",
  "lead": "فـ بكل ود وحُب",
  "inviteLine": "أودّ أن تكونا جزء من فرحتي فـ في محضر الحب أريدكم حولي\nلي شرف حضوركـم ولكم كل الحفـاوة والترحـيب في",
  "title": "حفل زفافي",
  "blessing": "وذلك بـمشيئة الله تعالـى",
  "date": {
    "year": 2026,
    "month": 3,
    "day": 26
  },
  "time": "20:00",
  "dateLine": "26 . March . 2026",
  "hijri": "7 من شوال عام 1447 هـ",
  "timeLine": "الاستقبال الساعة 8 مساءً",
  "weekStartsOn": 6,
  "arabicNumerals": false,
  "showCalendar": true,
  "placeLabel": "",
  "venue": "قاعة قمة فرح",
  "address": "الحرازات",
  "gateText": "",
  "showMap": true,
  "mapQuery": "قاعة قمة فرح الحرازات",
  "mapLink": "",
  "mapEmbed": "",
  "showPromo": true,
  "music": {
    "enabled": false,
    "file": "assets/music.mp3",
    "volume": 0.6,
    "fadeInSeconds": 3
  }
};
