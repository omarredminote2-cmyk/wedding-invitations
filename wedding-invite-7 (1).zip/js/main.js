/* مفيش حاجة تتعدل هنا: كل الإعدادات في config.js */

const stage  = document.querySelector('.stage');
const intro  = document.getElementById('intro');
const video  = document.getElementById('video');
const invite = document.getElementById('invite');
const frames = document.querySelectorAll('.frame');   // إطار كل صفحة

/* ============ 1) تعبئة الدعوة من config.js ============ */
const AR_DIGITS  = '٠١٢٣٤٥٦٧٨٩';
const MONTHS     = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
const DAYS_FULL  = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
const DAYS_SHORT = ['أحد','اثنين','ثلاثاء','أربعاء','خميس','جمعة','سبت'];

function fillInvite(cfg) {
  const num = (n) => (cfg.arabicNumerals ? String(n).replace(/\d/g, (d) => AR_DIGITS[d]) : String(n));
  const { year, month, day } = cfg.date;
  const start   = cfg.weekStartsOn ?? 6;
  const dim     = new Date(year, month, 0).getDate();                 // عدد أيام الشهر
  const offset  = (new Date(year, month - 1, 1).getDay() - start + 7) % 7; // فراغ قبل يوم 1
  const rows    = Math.ceil((offset + dim) / 7);
  const weekday = new Date(year, month - 1, day).getDay();

  let timeText = '';
  if (cfg.time) {
    const [h, m] = String(cfg.time).split(':').map(Number);
    timeText = `${num(h % 12 || 12)}:${num(String(m || 0).padStart(2, '0'))} ${h < 12 ? 'صباحًا' : 'مساءً'}`;
  }

  const text = {
    ...cfg,
    dateText: `${DAYS_FULL[weekday]}، ${num(day)} ${MONTHS[month - 1]} ${num(year)}`,
    timeText,
    calMonth: MONTHS[month - 1],
    calYear: num(year),
  };

  // أي عنصر عليه data-text بياخد النص ده، ولو فاضي بيتخفي
  document.querySelectorAll('[data-text]').forEach((el) => {
    const v = text[el.dataset.text];
    el.textContent = v || '';
    el.hidden = !v;
  });
  document.title = `دعوة زفاف ${cfg.groom} و ${cfg.bride}`;

  // الكاليندر
  const cal  = document.getElementById('cal');
  const grid = document.getElementById('calGrid');
  const add  = (txt, cls) => {
    const s = document.createElement('span');
    if (cls) s.className = cls;
    s.textContent = txt;
    grid.appendChild(s);
  };
  grid.replaceChildren();
  for (let i = 0; i < 7; i++) add(DAYS_SHORT[(start + i) % 7], 'dow');
  for (let i = 0; i < offset; i++) add('');
  for (let d = 1; d <= dim; d++) add(num(d), d === day ? 'on' : '');
  grid.style.gridTemplateRows = `auto repeat(${rows}, 1fr)`;
  grid.dataset.rows = rows;
  cal.setAttribute('aria-label', text.dateText);
  cal.hidden = cfg.showCalendar === false;

  // الخريطة واللينك
  const q = encodeURIComponent(cfg.mapQuery || cfg.venue);
  const embedSrc = (/src=["']([^"']+)["']/.exec(cfg.mapEmbed || '') || [])[1] || cfg.mapEmbed;
  const link  = cfg.mapLink  || `https://www.google.com/maps/search/?api=1&query=${q}`;
  const embed = embedSrc     || `https://www.google.com/maps?q=${q}&z=14&output=embed`;
  document.querySelectorAll('[data-maplink]').forEach((a) => { a.href = link; });
  document.getElementById('mapFrame').src = embed;
  document.getElementById('map').hidden = cfg.showMap === false;
  document.getElementById('promo').hidden = cfg.showPromo === false;
}
fillInvite(INVITE);

/* ============ 2) الموسيقى (من غير أي زرار) ============ */
const M = INVITE.music || {};
const music = M.enabled && M.file ? new Audio(M.file) : null;
let musicWanted = false;
let fadeTimer;
video.muted = true;                    // فيديو البداية من غير صوت خالص، الصوت الوحيد هو الموسيقى

function fadeIn() {
  const target = Math.min(Math.max(M.volume ?? 0.6, 0), 1);
  const steps  = (M.fadeInSeconds ?? 3) * 20;
  clearInterval(fadeTimer);
  if (!steps) { music.volume = target; return; }
  let i = 0;
  fadeTimer = setInterval(() => {
    music.volume = target * Math.min(++i / steps, 1);
    if (i >= steps) clearInterval(fadeTimer);
  }, 50);
}

let musicBegun = false;
function startMusic() {                  // أول لمسة: بنفتح الصوت بصوت صفر، والصوت بيعلى لما الفيديو يبدأ فعلًا
  if (!music || musicWanted) return;
  musicWanted = true;
  music.loop = true;
  music.volume = 0;
  music.play().catch(() => {
    // لو المتصفح منع التشغيل، نجرب تاني مع أول لمسة
    ['pointerdown', 'keydown', 'touchend'].forEach((ev) =>
      addEventListener(ev, () => music.play().catch(() => {}), { once: true }));
  });
}
function beginMusic() {
  if (!music || !musicWanted || musicBegun) return;
  musicBegun = true;
  if (music.paused) music.play().catch(() => {});
  fadeIn();
}

// لو المستخدم خرج من الصفحة أو قفل الشاشة الموسيقى تقف، ولما يرجع تكمّل
document.addEventListener('visibilitychange', () => {
  if (!music || !musicWanted) return;
  if (document.hidden) music.pause(); else music.play().catch(() => {});
});

/* ============ 3) فيديو البداية وفتح الدعوة ============ */
// بنشغّل الإطارات الظاهرة على الشاشة بس ونوقف الباقي، عشان الموبايل ما يتقلش
const watcher = 'IntersectionObserver' in window
  ? new IntersectionObserver((entries) => {
      entries.forEach(({ target, isIntersecting }) => {
        if (isIntersecting) target.play().catch(() => {});
        else target.pause();
      });
    }, { root: invite })
  : null;

let opened = false;
let failsafe;

function openInvite() {
  if (opened) return;
  opened = true;
  clearTimeout(failsafe);
  beginMusic();                          // لو الفيديو اتخطّى، الموسيقى تبدأ من هنا
  frames.forEach((f) => {
    f.currentTime = 0;
    if (watcher) watcher.observe(f);
    else f.play().catch(() => {});
  });
  stage.classList.add('open');
  invite.removeAttribute('inert');
  invite.removeAttribute('aria-hidden');
  setTimeout(() => { intro.hidden = true; video.pause(); }, 1400);
}

function startVideo() {
  if (opened || intro.classList.contains('playing')) return;
  intro.classList.add('playing', 'loading');   // علامة التحميل بتظهر لحد ما الفيديو يبدأ
  startMusic();                          // الضغطة دي هي اللي بتسمح للمتصفح يشغّل الصوت
  clearTimeout(failsafe);
  failsafe = setTimeout(openInvite, 7000);     // لو الفيديو ما بدأش خلال 7 ثواني (نت ضعيف) نفتح الدعوة
  if (video.error) { openInvite(); return; }   // الفيديو مش شغال على الجهاز ده: نفتح الدعوة علطول
  video.play().catch(openInvite);
}

video.addEventListener('playing', () => {
  intro.classList.remove('loading');
  clearTimeout(failsafe);
  beginMusic();                          // الموسيقى تبدأ مع الفيديو مش قبله
  const left = isFinite(video.duration) ? video.duration - video.currentTime : 20;
  failsafe = setTimeout(openInvite, (left + 4) * 1000);   // أمان لو الفيديو وقف في النص
  const f0 = frames[0];                  // نحمّل أول إطار دلوقتي من غير ما نزاحم فيديو البداية
  if (f0 && f0.preload === 'none') { f0.preload = 'auto'; f0.load(); }
});
video.addEventListener('waiting', () => intro.classList.add('loading'));

intro.addEventListener('click', startVideo);
intro.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') startVideo(); });
video.addEventListener('ended', openInvite);
video.addEventListener('error', () => { if (intro.classList.contains('playing')) openInvite(); });   // الخطأ قبل الضغطة ما يفتحش الدعوة لوحده
