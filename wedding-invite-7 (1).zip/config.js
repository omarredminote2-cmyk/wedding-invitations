/* ملف الإعدادات (اتعمل من محرر الدعوة، وتقدر تعدّله بإيدك برضو: غيّر القيم وسيب الباقي) */
const INVITE = {
  "groom": "علي",
  "bride": "أسماء",
  "bismillah": "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
  "verse": "وَمِنْ آيَاتِهِ أَنْ خَلَقَ لَكُمْ مِنْ أَنْفُسِكُمْ أَزْوَاجًا لِتَسْكُنُوا إِلَيْهَا وَجَعَلَ بَيْنَكُمْ مَوَدَّةً وَرَحْمَةً ۚ إِنَّ فِي ذَٰلِكَ لَآيَاتٍ لِقَوْمٍ يَتَفَكَّرُونَ",
  "inviteLine": "يدعوانكم لحضور حفل زفافهما",
  "dua": "بارك الله لهما وبارك عليهما وجمع بينهما في خير",
  "closing": "وجودكم يتمم فرحتنا",
  "date": {
    "year": 2027,
    "month": 5,
    "day": 23
  },
  "time": "17:00",
  "weekStartsOn": 6,
  "arabicNumerals": true,
  "showCalendar": true,
  "placeLabel": "المكان",
  "venue": "دومين دي تييول",
  "address": "شانتيي، واز",
  "gateText": "تُفتح البوابة في الخامسة",
  "mapButton": "افتح في الخرائط",
  "showMap": true,
  "showPromo": true,
  "mapQuery": "Domaine de Thieulle Chantilly Oise France",
  "mapLink": "",
  "mapEmbed": "",
  "music": {
    "enabled": true,
    "file": "assets/music.mp3",
    "volume": 0.6,
    "fadeInSeconds": 3
  }
};
