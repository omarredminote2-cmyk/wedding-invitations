(function () {
  var C = window.INVITE, $ = function (s) { return document.querySelector(s); }, noop = function () {};
  var video = $('#video'), start = $('#start'), tx = $('#tx'), disc = $('#disc'), lab = $('.label');
  var prev = $('#prev'), next = $('#next'), dots = $('#dots');
  var MON = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
  var DAY = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>'); }
  function dg(s) { return C.digits === 'en' ? String(s) : String(s).replace(/\d/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.charAt(d); }); }
  function el(tag, text, cls) { return text ? '<' + tag + (cls ? ' class="' + cls + '"' : '') + '>' + esc(text) + '</' + tag + '>' : ''; }

  function format() {
    var o = { dayName: '', date: '', time: '' };
    var m = /^(\d{4})-(\d\d)-(\d\d)$/.exec(C.dateISO || '');
    if (m) { o.dayName = DAY[new Date(+m[1], +m[2] - 1, +m[3]).getDay()]; o.date = dg(+m[3] + ' ' + MON[+m[2] - 1] + ' ' + m[1]); }
    var t = /^(\d\d):(\d\d)$/.exec(C.time24 || '');
    if (t) { var h = +t[1]; o.time = 'الساعة ' + dg((h % 12 || 12) + ':' + t[2]) + (h < 12 ? ' صباحًا' : ' مساءً'); }
    return o;
  }

  function build() {
    var f = format(), t = [], a;
    var names = [C.groom, C.bride].filter(Boolean).map(esc).join(' <i>و</i> ');
    a = el('p', C.verse, 'v') + el('p', C.intro) + (names ? '<h2>' + names + '</h2>' : '');
    if (a) t.push(a);
    a = el('div', f.dayName, 'big') + el('div', f.date, 'mid') + el('p', f.time);
    if (a) t.push(el('small', 'ميعاد الفرح') + a);
    var map = /^https?:/.test(C.mapUrl || '') ? '<a href="' + esc(C.mapUrl) + '" target="_blank" rel="noopener">افتح الموقع على الخريطة</a>' : '';
    a = el('h2', C.venue) + el('p', C.address) + map;
    if (a) t.push(el('small', 'مكان الفرح') + a);
    a = el('p', C.dua, 'v') + el('p', C.closing, 'c');
    if (a) t.push(a);
    return t.length ? t : ['<p>الدعوة فاضية</p>'];
  }

  var T = [], i = 0, busy = false, opened = false, started = false, playMusic = false;

  function fit() {
    tx.style.setProperty('--s', 1);
    var h = tx.offsetHeight, a = lab.clientHeight * 0.7;
    if (h > a) tx.style.setProperty('--s', Math.max(0.5, a / h));
  }
  function paint() {
    tx.innerHTML = T[i];
    [].forEach.call(dots.children, function (d, k) { d.className = k === i ? 'on' : ''; });
    prev.disabled = i === 0;
    next.disabled = i === T.length - 1;
    fit();
  }
  function refresh() {
    T = build();
    if (i >= T.length) i = T.length - 1;
    dots.innerHTML = T.map(function () { return '<b></b>'; }).join('');
    paint(); syncMusic();
  }
  function go(n) {
    if (busy || n < 0 || n >= T.length) return;
    busy = true; i = n;
    disc.classList.add('fast'); tx.classList.add('out');
    setTimeout(function () { paint(); tx.classList.remove('out'); }, 260);
    setTimeout(function () { disc.classList.remove('fast'); busy = false; }, 800);
  }
  prev.onclick = function () { go(i - 1); };
  next.onclick = function () { go(i + 1); };

  // swipe: left = next, right = previous
  var x0 = null, ui = $('#ui');
  ui.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; }, { passive: true });
  ui.addEventListener('touchend', function (e) {
    if (x0 === null) return;
    var dx = e.changedTouches[0].clientX - x0; x0 = null;
    if (Math.abs(dx) > 50) go(dx < 0 ? i + 1 : i - 1);
  }, { passive: true });

  // music: unlocked on the first tap, plays once the video ends
  var music = null, musicSrc = '';
  function syncMusic() {
    var M = C.music || {};
    if (M.enabled === false || !M.file) { if (music) music.pause(); return; }
    if (!music || musicSrc !== M.file) {
      if (music) music.pause();
      music = new Audio(M.file); music.loop = true; musicSrc = M.file;
    }
    music.volume = M.volume == null ? 0.5 : M.volume;
    if (opened && playMusic) music.play().catch(noop);
  }

  function open(skip) {
    if (opened) return;
    if (skip === true) { started = false; playMusic = false; try { video.pause(); video.currentTime = video.duration || 4; } catch (e) {} }
    else playMusic = true;
    opened = true;
    document.body.classList.add('open');
    syncMusic();
  }
  function replay() {
    opened = false; started = false; playMusic = false; i = 0;
    document.body.classList.remove('open');
    if (music) music.pause();
    paint(); start.classList.remove('gone');
    try { video.currentTime = 0; } catch (e) {}
  }

  start.onclick = function () {
    started = true; start.classList.add('gone');
    if (music) {
      music.muted = true;
      music.play().then(function () { music.pause(); music.currentTime = 0; music.muted = false; }).catch(function () { music.muted = false; });
    }
    video.muted = false;
    var p = video.play();
    if (p && p.catch) p.catch(function () { open(); });
  };
  video.addEventListener('ended', function () { if (started) open(); });
  video.addEventListener('error', function () { if (started) open(); });

  window.Invite = { refresh: refresh, open: open, replay: replay, format: format };
  refresh();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(fit);
})();
