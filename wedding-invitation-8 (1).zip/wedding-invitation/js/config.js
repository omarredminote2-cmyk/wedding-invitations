/* بيانات الدعوة — أنشأها محرر الدعوة. أي نص تتركه فاضي يختفي من الدعوة. الألوان والخطوط في css/style.css */
window.INVITATION = {
  "verse": {
    "text": "وَمِنْ آيَاتِهِ أَنْ خَلَقَ لَكُم مِّنْ أَنفُسِكُمْ أَزْوَاجًا لِّتَسْكُنُوا إِلَيْهَا وَجَعَلَ بَيْنَكُم مَّوَدَّةً وَرَحْمَةً ۚ إِنَّ فِي ذَٰلِكَ لَآيَاتٍ لِّقَوْمٍ يَتَفَكَّرُونَ",
    "closing": "صدق الله العظيم",
    "source": "سورة الروم – الآية 21"
  },
  "couple": {
    "lead": "يتشرف أهل العروسين بدعوتكم لحضور حفل زفاف",
    "groom": "عمر",
    "and": "و",
    "bride": "سلمى",
    "dua": "اللهم بارك لهما وبارك عليهما واجمع بينهما في خير",
    "note": "بحضوركم تكتمل فرحتنا"
  },
  "event": {
    "date": {
      "year": 2026,
      "month": 11,
      "day": 26
    },
    "time": "20:30",
    "weekStart": 6,
    "numerals": "en",
    "showCalendar": true,
    "venueName": "قاعة القصر المريوطية",
    "venueAddress": "طريق سقارة",
    "gate": "الدخول من البوابة الرئيسية",
    "showMap": true,
    "mapUrl": "",
    "mapButton": "عرض الموقع على الخريطة"
  },
  "promo": {
    "text": "DM to make ur special invite",
    "phone": "201157395271",
    "message": "السلام عليكم، شفت دعوة زفاف {groom} و{bride} ونفسي أعمل دعوة زي دي"
  },
  "share": {
    "title": "دعوة زفاف",
    "description": "",
    "image": "",
    "siteUrl": ""
  },
  "photos": [
    {
      "src": "assets/images/couple-1.jpg",
      "alt": "صورة العروسين"
    }
  ],
  "frame": "assets/images/frame-oval.webp",
  "media": {
    "introVideo": "assets/video/intro.mp4",
    "introPoster": "assets/images/intro-poster.jpg",
    "backgroundStill": "assets/images/background-still.jpg",
    "backgroundVideo": "assets/video/background.mp4",
    "music": {
      "enabled": true,
      "file": "assets/audio/music.mp3",
      "volume": 0.7,
      "fadeInSeconds": 2
    }
  }
};
