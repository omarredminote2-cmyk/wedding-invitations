/* =========================================================
   سلوك الدعوة — لا تحتاج تعديل هذا الملف في الاستخدام العادي
   (النصوص والملفات في js/config.js)

   التسلسل:
   1) شاشة البداية: أول لقطة من فيديو الافتتاح بدون أي نص أو زر.
   2) ضغطة في أي مكان → يعمل فيديو الافتتاح (صامت) وتبدأ الموسيقى.
   3) عند انتهاء الفيديو → تظهر الخلفية (فيديو متكرر أو صورة ثابتة) وتظهر الدعوة.
   ========================================================= */
(function () {
  "use strict";

  var C = window.INVITATION;
  if (!C) {
    console.error("لم يتم تحميل js/config.js");
    return;
  }

  var $ = function (id) { return document.getElementById(id); };
  var root = document.documentElement;
  var media = C.media || {};

  var introVideo = $("introVideo");
  var bgVideo = $("bgVideo");
  var startLayer = $("startLayer");
  var invitation = $("invitation");

  var state = "idle";          // idle → playing → open
  var safetyTimer = null;
  var audio = null;
  var bgReady = false;

  /* ---------------------------------------------------------
     1) تعبئة النصوص والصور من config.js
     --------------------------------------------------------- */
  function setText(id, value) { var el = $(id); el.textContent = value || ""; el.hidden = !value; }

  /* مسار الملف ← الرابط الفعلي (المحرر يستخدم ASSET_URLS للملفات المضمّنة أو المرفوعة) */
  function U(p) { return (window.ASSET_URLS && window.ASSET_URLS[p]) || p; }

  var MONTHS = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
  var DAYS = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];   // ترتيب getDay()
  var DAYS_SHORT = ["ح", "ن", "ث", "ر", "خ", "ج", "س"];
  var HEART = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>';

  function digits(s, mode) {
    s = String(s);
    return mode === "ar" ? s.replace(/\d/g, function (d) { return "٠١٢٣٤٥٦٧٨٩".charAt(d); }) : s;
  }

  function formatTime(t) {
    var m = /^(\d{1,2}):(\d{2})$/.exec(t || "");
    if (!m) return t || "";
    var h = +m[1];
    return "الساعة " + (h % 12 || 12) + ":" + m[2] + (h < 12 ? " صباحًا" : " مساءً");
  }

  /* التقويم يتبني من التاريخ: عدد الأيام والصفوف وموضع اليوم المختار */
  function calendar(dt, e) {
    var box = $("calendar"), ar = e.numerals, i;
    box.innerHTML = "";
    box.hidden = !e.showCalendar || !dt;
    if (box.hidden) return;
    var ws = typeof e.weekStart === "number" ? e.weekStart : 6, y = dt.getFullYear(), m = dt.getMonth();
    var html = '<div class="cal__title">' + MONTHS[m] + " " + digits(y, ar) + '</div><div class="cal__grid">';
    for (i = 0; i < 7; i++) html += '<span class="cal__dow">' + DAYS_SHORT[(ws + i) % 7] + "</span>";
    var lead = (new Date(y, m, 1).getDay() - ws + 7) % 7, n = new Date(y, m + 1, 0).getDate();
    for (i = 0; i < lead; i++) html += "<span></span>";
    for (i = 1; i <= n; i++) {
      html += i === dt.getDate()
        ? '<span class="cal__day is-on">' + HEART + "<b>" + digits(i, ar) + "</b></span>"
        : '<span class="cal__day">' + digits(i, ar) + "</span>";
    }
    box.innerHTML = html + "</div>";
  }

  function render() {

    var v = C.verse || {};
    setText("verseText", v.text);
    setText("verseClosing", v.closing);
    setText("verseSource", v.source);

    var c = C.couple || {};
    setText("coupleLead", c.lead);
    setText("groomName", c.groom);
    setText("coupleAnd", c.and);
    setText("brideName", c.bride);
    setText("coupleDua", c.dua);
    setText("coupleNote", c.note);

    var e = C.event || {};
    var d = e.date || {}, ar = e.numerals, dt = new Date(d.year, (d.month || 1) - 1, d.day);
    if (isNaN(dt.getTime())) dt = null;
    setText("evWeekday", dt && DAYS[dt.getDay()]);
    setText("evDay", dt && digits(dt.getDate(), ar));
    setText("evMonthYear", dt && MONTHS[dt.getMonth()] + " " + digits(dt.getFullYear(), ar));
    setText("evTime", digits(formatTime(e.time), ar));
    calendar(dt, e);
    setText("evVenue", e.venueName);
    setText("evAddress", e.venueAddress);
    setText("evGate", e.gate);
    setText("mapLabel", e.mapButton);
    $("mapBtn").hidden = !e.showMap;

    var mapUrl = e.mapUrl;
    if (!mapUrl) {
      var q = [e.venueName, e.venueAddress].filter(Boolean).join(" ");
      mapUrl = "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(q);
    }
    $("mapBtn").href = mapUrl;

    // الصور داخل الإطار الزخرفي
    var P = C.promo || {}, phone = String(P.phone || "").replace(/\D/g, "");
    var wa = String(P.message || "").replace(/\{groom\}/g, c.groom || "").replace(/\{bride\}/g, c.bride || "");
    setText("promoText", P.text);
    $("promo").hidden = !P.text || !phone;
    $("promoLink").href = "https://wa.me/" + phone + (wa ? "?text=" + encodeURIComponent(wa) : "");

    var frames = $("frames");
    frames.innerHTML = "";
    (C.photos || []).forEach(function (p) {
      var fig = document.createElement("figure");
      fig.className = "frame";

      var photo = document.createElement("img");
      photo.className = "frame__photo";
      photo.src = U(p.src);
      photo.alt = p.alt || "";
      photo.loading = "lazy";
      photo.decoding = "async";

      var ring = document.createElement("img");
      ring.className = "frame__ring";
      ring.src = U(C.frame);
      ring.alt = "";
      ring.setAttribute("aria-hidden", "true");
      ring.loading = "lazy";
      ring.decoding = "async";

      fig.appendChild(photo);
      fig.appendChild(ring);
      frames.appendChild(fig);
    });

  }

  /* وسائط الخلفية والافتتاح (تُجهَّز مرة واحدة) */
  function initMedia() {
    $("bgStill").src = U(media.backgroundStill || "");
    $("bgFill").src = U(media.backgroundStill || "");

    introVideo.muted = true;            // الافتتاح صامت دائمًا
    introVideo.defaultMuted = true;
    introVideo.poster = U(media.introPoster || "");
    introVideo.src = U(media.introVideo || "");

    if (media.backgroundVideo) {
      bgVideo.muted = true;
      bgVideo.defaultMuted = true;
      bgVideo.addEventListener("canplay", function () {
        bgReady = true;
        showBackgroundVideo();
      });
      // لو الملف غير موجود: لا نفعل شيئًا وتبقى الصورة الثابتة
      bgVideo.addEventListener("error", function () { bgReady = false; });
      bgVideo.src = U(media.backgroundVideo);
    }
  }

  /* ---------------------------------------------------------
     2) الموسيقى (تبدأ مع أول ضغطة، بدون زر صوت)
     --------------------------------------------------------- */
  function stopMusic() { if (audio) { audio.pause(); audio = null; } }

  function startMusic() {
    stopMusic();
    var m = media.music;
    if (!m || !m.enabled || !m.file) return;

    audio = new Audio(U(m.file));
    audio.loop = true;
    audio.preload = "auto";
    audio.volume = 0;

    var target = typeof m.volume === "number" ? m.volume : 0.7;
    var ms = (m.fadeInSeconds || 0) * 1000;

    var p = audio.play();
    if (p && p.then) {
      p.then(function () { fadeVolume(target, ms); }).catch(function () {});
    }
  }

  function fadeVolume(target, ms) {
    if (!audio) return;
    if (!ms) { audio.volume = target; return; }
    var steps = 30, i = 0;
    var timer = setInterval(function () {
      i++;
      try { audio.volume = Math.min(target, target * (i / steps)); } catch (e) {}
      if (i >= steps) clearInterval(timer);
    }, ms / steps);
  }

  // إيقاف الموسيقى عند مغادرة التبويب واستئنافها عند العودة
  document.addEventListener("visibilitychange", function () {
    if (!audio) return;
    if (document.hidden) audio.pause();
    else audio.play().catch(function () {});
  });

  /* ---------------------------------------------------------
     3) مراحل العرض
     --------------------------------------------------------- */
  function start() {
    if (state !== "idle") return;
    state = "playing";

    startMusic();

    var played = introVideo.play();
    if (played && played.catch) {
      played.catch(openInvitation);          // تعذّر التشغيل → ننتقل للدعوة مباشرة
    }

    // شبكة أمان: لو تعطل الفيديو لا يبقى الزائر عالقًا
    var d = isFinite(introVideo.duration) && introVideo.duration > 0 ? introVideo.duration : 6;
    safetyTimer = setTimeout(openInvitation, (d + 5) * 1000);
  }

  function openInvitation() {
    if (state === "open") return;
    state = "open";
    clearTimeout(safetyTimer);

    root.classList.remove("is-intro");
    root.classList.add("is-open");
    startLayer.hidden = true;
    invitation.removeAttribute("inert");
    window.scrollTo(0, 0);

    showBackgroundVideo();
    setTimeout(function () { introVideo.pause(); }, 1500);   // بعد تلاشي فيديو الافتتاح
  }

  function showBackgroundVideo() {
    if (!bgReady || state !== "open") return;
    var p = bgVideo.play();
    var on = function () { bgVideo.classList.add("is-on"); };
    if (p && p.then) p.then(on).catch(function () {});
    else on();
  }

  /* ---------------------------------------------------------
     4) الأحداث
     --------------------------------------------------------- */
  startLayer.addEventListener("click", start);
  startLayer.addEventListener("keydown", function (ev) {
    if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); start(); }
  });

  introVideo.addEventListener("ended", openInvitation);
  introVideo.addEventListener("error", function () {
    // الفيديو غير متاح: أول ضغطة تفتح الدعوة مباشرة
    if (state === "playing") openInvitation();
  });

  window.InvitationApp = {   // واجهة صغيرة يستخدمها محرر الدعوة
    render: render,
    startMusic: startMusic,
    stopMusic: stopMusic,
    setVolume: function (v) { if (audio) audio.volume = v; },
    open: function () { if (state === "idle") { state = "playing"; openInvitation(); } },   // تخطّي الافتتاح أثناء التعديل
  };

  render();
  initMedia();
  startLayer.focus({ preventScroll: true });
})();
